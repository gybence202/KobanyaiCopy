﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDoList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBoxPriority.Items.AddRange(new string[] { "Alacsony", "Közepes", "Magas" });
            listBoxTasks.DrawMode = DrawMode.OwnerDrawFixed; // OwnerDraw beállítás
        }
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string task = textBoxTask.Text;
            string priority = comboBoxPriority.SelectedItem?.ToString() ?? "Nincs megadva";
            string date = dateTimePicker.Value.ToShortDateString();
            string completed = checkBoxCompleted.Checked ? "Kész" : "";

            if (!string.IsNullOrWhiteSpace(task))
            {
                listBoxTasks.Items.Add($"{task} - Prioritás: {priority} - Dátum: {date} - {completed}");
                ClearFields(); // Törölni a mezőket
            }
            else
            {
                MessageBox.Show("Kérlek, add meg a feladatot!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void listBoxTasks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxTasks.SelectedItem != null)
            {
                string selectedTask = listBoxTasks.SelectedItem.ToString();
                string[] parts = selectedTask.Split(new[] { " - " }, StringSplitOptions.None);

                // Beviteli mezők kitöltése a kiválasztott feladat adataival
                textBoxTask.Text = parts[0]; // Feladat
                comboBoxPriority.SelectedItem = parts[1].Replace("Prioritás: ", ""); // Prioritás
                dateTimePicker.Value = DateTime.Parse(parts[2].Replace("Dátum: ", "")); // Dátum
                checkBoxCompleted.Checked = parts.Length > 3 && parts[3] == "Kész"; // Kész jelölés
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (listBoxTasks.SelectedItem != null)
            {
                string task = textBoxTask.Text;
                string priority = comboBoxPriority.SelectedItem?.ToString() ?? "Nincs megadva";
                string date = dateTimePicker.Value.ToShortDateString();
                string completed = checkBoxCompleted.Checked ? "Kész" : "";

                if (!string.IsNullOrWhiteSpace(task))
                {
                    int selectedIndex = listBoxTasks.SelectedIndex;
                    listBoxTasks.Items[selectedIndex] = $"{task} - Prioritás: {priority} - Dátum: {date} - {completed}";
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Kérlek, add meg a feladatot!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (listBoxTasks.SelectedItem != null)
            {
                listBoxTasks.Items.Remove(listBoxTasks.SelectedItem);
                ClearFields();
            }
        }

        private void listBoxTasks_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            // Feladat szövegének beolvasása
            string itemText = listBoxTasks.Items[e.Index].ToString();

            // Hátteret világoskék színűre állítunk, ha az elem ki van választva
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                e.Graphics.FillRectangle(Brushes.LightBlue, e.Bounds);
            }
            else if (itemText.Contains("Kész"))
            {
                e.Graphics.FillRectangle(Brushes.LightGreen, e.Bounds);
            }
            else
            {
                e.Graphics.FillRectangle(Brushes.White, e.Bounds); // Alap háttér
            }

            // Szöveg színének beállítása
            Color textColor = Color.Black;

            e.Graphics.DrawString(itemText, e.Font, new SolidBrush(textColor), e.Bounds);
            e.DrawFocusRectangle();
        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = new StreamWriter("Teendok.txt"))
            {
                foreach (var item in listBoxTasks.Items)
                {
                    writer.WriteLine(item.ToString());
                }
            }

            MessageBox.Show("Feladatok mentve a Teendok.txt fájlba.", "Mentés", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void ClearFields()
        {
            textBoxTask.Clear();
            comboBoxPriority.SelectedIndex = -1;
            dateTimePicker.Value = DateTime.Now;
            checkBoxCompleted.Checked = false;
        }
    }
}
